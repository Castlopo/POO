#include "GestorRegistros.h"

using namespace std;

void mostrarMenuPrincipal() {
    cout << "1. Evaluacion de un Curso\n";
    cout << "2. Gestion de Materias\n";
    cout << "3. Control de Tareas\n";
    cout << "4. Agenda\n";
    cout << "5. Salir\n";
    cout << "Seleccione una opcion: ";
}

void mostrarMenuAgenda() {
    cout << "1. Agregar recordatorio\n";
    cout << "2. Listar recordatorios\n";
    cout << "3. Mostrar detalles de un recordatorio\n";
    cout << "4. Modificar un recordatorio\n";
    cout << "5. Eliminar recordatorio\n";
    cout << "6. Guardar cambios\n";
    cout << "7. Regresar al menu anterior\n";
    cout << "Seleccione una opcion: ";
}

int main() {
    GestorRegistros gestor;
    gestor.cargarDesdeArchivo("registros.txt");

    int opcionPrincipal, opcionAgenda;

    do {
        mostrarMenuPrincipal();
        cin >> opcionPrincipal;

        switch (opcionPrincipal) {
        case 4:
            do {
                mostrarMenuAgenda();
                cin >> opcionAgenda;

                switch (opcionAgenda) {
                case 1: {
                    string id, titulo, descripcion, fecha;
                    cout << "ID: "; cin >> id;
                    cin.ignore();
                    cout << "Titulo: "; getline(cin, titulo);
                    cout << "Descripcion: "; getline(cin, descripcion);
                    cout << "Fecha: "; getline(cin, fecha);
                    gestor.agregarRegistro(Registro(id, titulo, descripcion, fecha));
                    break;
                }
                case 2:
                    gestor.listarRegistros();
                    break;
                case 3: {
                    size_t index;
                    cout << "Indice del recordatorio: "; cin >> index;
                    gestor.mostrarDetalles(index - 1);
                    break;
                }
                case 4: {
                    size_t index;
                    cout << "Indice del recordatorio a modificar: "; cin >> index;
                    string id, titulo, descripcion, fecha;
                    cout << "Nuevo ID: "; cin >> id;
                    cin.ignore();
                    cout << "Nuevo Titulo: "; getline(cin, titulo);
                    cout << "Nueva Descripcion: "; getline(cin, descripcion);
                    cout << "Nueva Fecha: "; getline(cin, fecha);
                    gestor.modificarRegistro(index - 1, Registro(id, titulo, descripcion, fecha));
                    break;
                }
                case 5: {
                    size_t index;
                    cout << "Indice del recordatorio a eliminar: "; cin >> index;
                    gestor.eliminarRegistro(index - 1);
                    break;
                }
                case 6:
                    gestor.guardarEnArchivo("registros.txt");
                    break;
                }
            } while (opcionAgenda != 7);
            break;

        case 5:
            gestor.guardarEnArchivo("registros.txt");
            cout << "Gracias por usar el programa.\n";
            break;
        }
    } while (opcionPrincipal != 5);

    return 0;
}
