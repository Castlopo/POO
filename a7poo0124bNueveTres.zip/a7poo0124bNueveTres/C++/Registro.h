#ifndef REGISTRO_H
#define REGISTRO_H

#include <string>
using namespace std;

class Registro {
private:
    string id;
    string titulo;
    string descripcion;
    string fecha;

public:
    Registro(string id, string titulo, string descripcion, string fecha)
        : id(id), titulo(titulo), descripcion(descripcion), fecha(fecha) {}

    // Getters y Setters
    string getId() const { return id; }
    void setId(const string& newId) { id = newId; }

    string getTitulo() const { return titulo; }
    void setTitulo(const string& newTitulo) { titulo = newTitulo; }

    string getDescripcion() const { return descripcion; }
    void setDescripcion(const string& newDescripcion) { descripcion = newDescripcion; }

    string getFecha() const { return fecha; }
    void setFecha(const string& newFecha) { fecha = newFecha; }

    // Representación como string
    string toString() const {
        return id + "|" + titulo + "|" + descripcion + "|" + fecha;
    }
};

#endif
