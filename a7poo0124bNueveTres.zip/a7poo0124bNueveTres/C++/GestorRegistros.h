#ifndef GESTORREGISTROS_H
#define GESTORREGISTROS_H

#include "Registro.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

class GestorRegistros {
private:
    vector<Registro> registros;

public:
    void agregarRegistro(const Registro& registro) {
        registros.push_back(registro);
    }

    void listarRegistros() const {
        for (size_t i = 0; i < registros.size(); ++i) {
            cout << i + 1 << ". " << registros[i].getTitulo() << " (" << registros[i].getFecha() << ")\n";
        }
    }

    void mostrarDetalles(size_t index) const {
        if (index < registros.size()) {
            const Registro& reg = registros[index];
            cout << "ID: " << reg.getId() << "\n";
            cout << "Título: " << reg.getTitulo() << "\n";
            cout << "Descripción: " << reg.getDescripcion() << "\n";
            cout << "Fecha: " << reg.getFecha() << "\n";
        } else {
            cout << "Índice no válido.\n";
        }
    }

    void modificarRegistro(size_t index, const Registro& nuevoRegistro) {
        if (index < registros.size()) {
            registros[index] = nuevoRegistro;
        } else {
            cout << "Índice no válido.\n";
        }
    }

    void eliminarRegistro(size_t index) {
        if (index < registros.size()) {
            registros.erase(registros.begin() + index);
        } else {
            cout << "Índice no válido.\n";
        }
    }

    void guardarEnArchivo(const string& nombreArchivo) const {
        ofstream archivo(nombreArchivo, ios::trunc);
        for (const auto& reg : registros) {
            archivo << reg.toString() << "\n";
        }
        archivo.close();
    }

    void cargarDesdeArchivo(const string& nombreArchivo) {
        registros.clear();
        ifstream archivo(nombreArchivo);
        string linea;
        while (getline(archivo, linea)) {
            istringstream stream(linea);
            string id, titulo, descripcion, fecha;
            getline(stream, id, '|');
            getline(stream, titulo, '|');
            getline(stream, descripcion, '|');
            getline(stream, fecha, '|');
            registros.emplace_back(id, titulo, descripcion, fecha);
        }
        archivo.close();
    }
};

#endif
