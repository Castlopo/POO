#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Alumno {
private:
    string nombre;
    string matricula;
    float promedio;
    int anio;

public:
    Alumno() : nombre(""), matricula(""), promedio(0.0), anio(0) {}

    Alumno(string nombre, string matricula, float promedio, int anio)
        : nombre(nombre), matricula(matricula), promedio(promedio), anio(anio) {}

    string getNombre() const { return nombre; }
    string getMatricula() const { return matricula; }
    float getPromedio() const { return promedio; }
    int getAnio() const { return anio; }

    void setNombre(const string& nuevoNombre) { nombre = nuevoNombre; }
    void setMatricula(const string& nuevaMatricula) { matricula = nuevaMatricula; }
    void setPromedio(float nuevoPromedio) { promedio = nuevoPromedio; }
    void setAnio(int nuevoAnio) { anio = nuevoAnio; }

    void mostrarInformacion() const {
        cout << "Nombre: " << nombre << "\nMatricula: " << matricula
             << "\nPromedio: " << promedio << "\nAnio: " << anio << "\n";
    }
};

class RegistroAlumnos {
private:
    vector<Alumno> alumnos;
    vector<bool> registrosLibres;

public:
    RegistroAlumnos(int maxAlumnos) {
        alumnos.resize(maxAlumnos);
        registrosLibres.resize(maxAlumnos, true);
    }

    void inicializarRegistros() {
        for (size_t i = 0; i < registrosLibres.size(); i++) {
            registrosLibres[i] = true;
        }
        cout << "Registros inicializados.\n";
    }

    void agregarAlumno(const Alumno& nuevoAlumno) {
        for (size_t i = 0; i < alumnos.size(); i++) {
            if (registrosLibres[i]) {
                alumnos[i] = nuevoAlumno;
                registrosLibres[i] = false;
                cout << "Alumno agregado en el registro " << i + 1 << ".\n";
                return;
            }
        }
        cout << "No hay espacio disponible para agregar mas alumnos.\n";
    }

    void listarAlumnos() const {
        bool hayAlumnos = false;
        for (size_t i = 0; i < alumnos.size(); i++) {
            if (!registrosLibres[i]) {
                cout << "Registro " << i + 1 << ":\n";
                alumnos[i].mostrarInformacion();
                hayAlumnos = true;
            }
        }
        if (!hayAlumnos) {
            cout << "No hay alumnos registrados.\n";
        }
    }

    void eliminarAlumno(int indice) {
        if (indice >= 0 && indice < registrosLibres.size() && !registrosLibres[indice]) {
            registrosLibres[indice] = true;
            cout << "Alumno en el registro " << indice + 1 << " eliminado.\n";
        } else {
            cout << "Indice no valido o el registro ya esta vacio.\n";
        }
    }
};

int main() {
    RegistroAlumnos registro(100);
    registro.inicializarRegistros();

    Alumno alumno1("Juan Perez", "MAT12345", 8.7, 2023);
    registro.agregarAlumno(alumno1);

    Alumno alumno2("Maria Lopez", "MAT67890", 9.2, 2022);
    registro.agregarAlumno(alumno2);

    cout << "\nListando alumnos:\n";
    registro.listarAlumnos();

    cout << "\nEliminando el primer alumno...\n";
    registro.eliminarAlumno(0);

    cout << "\nListando alumnos nuevamente:\n";
    registro.listarAlumnos();

    return 0;
}
