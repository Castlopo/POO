/*
NickName: NueveTres
Tiempo: 01:49
Codigo: j56
*/
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
using namespace std;

const int MAX_MATERIAS = 10;
const int MAX_PRERREQUISITOS = 3;

struct Materia {
    string clave;
    string nombre;
    string prerrequisitos[MAX_PRERREQUISITOS];
    int numPrerrequisitos;
};

Materia listaMaterias[MAX_MATERIAS];
int numMaterias = 0;

void limpiarPantalla() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

void cargarMateriasDesdeArchivo(const string& nombreArchivo) {
    ifstream archivo(nombreArchivo);
    if (!archivo.is_open()) {
        cout << "Error: No se pudo abrir el archivo " << nombreArchivo << ".\n";
        return;
    }

    string linea;
    while (getline(archivo, linea)) {
        stringstream ss(linea);
        Materia materia;
        string prerrequisitos[MAX_PRERREQUISITOS];
        string campo;

        getline(ss, materia.clave, '|');
        getline(ss, materia.nombre, '|');

        int index = 0;
        while (index < MAX_PRERREQUISITOS && getline(ss, campo, '|')) {
            if (campo != "_") {
                materia.prerrequisitos[index++] = campo;
            }
        }
        materia.numPrerrequisitos = index;

        listaMaterias[numMaterias++] = materia;
    }

    archivo.close();
    cout << "Materias cargadas correctamente desde el archivo.\n";
}

void guardarMateriasEnArchivo(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (!archivo.is_open()) {
        cout << "Error: No se pudo abrir el archivo " << nombreArchivo << " para escribir.\n";
        return;
    }

    for (int i = 0; i < numMaterias; i++) {
        archivo << listaMaterias[i].clave << "|";
        archivo << listaMaterias[i].nombre << "|";

        for (int j = 0; j < MAX_PRERREQUISITOS; j++) {
            if (j < listaMaterias[i].numPrerrequisitos) {
                archivo << listaMaterias[i].prerrequisitos[j];
            } else {
                archivo << "_";
            }
            if (j < MAX_PRERREQUISITOS - 1) archivo << "|";
        }
        archivo << "\n";
    }

    archivo.close();
    cout << "Materias guardadas correctamente en el archivo.\n";
}

void listarMaterias() {
    limpiarPantalla();
    cout << left << setw(10) << "Clave"
         << setw(35) << "Nombre"
         << "Prerrequisitos\n";
    cout << string(60, '-') << "\n";

    for (int i = 0; i < numMaterias; i++) {
        cout << left << setw(10) << listaMaterias[i].clave
             << setw(35) << listaMaterias[i].nombre;

        for (int j = 0; j < listaMaterias[i].numPrerrequisitos; j++) {
            cout << listaMaterias[i].prerrequisitos[j];
            if (j < listaMaterias[i].numPrerrequisitos - 1)
                cout << ", ";
        }
        cout << "\n";
    }
    cout << endl;
}

bool validarEntrada(const string& entrada) {
    for (char c : entrada) {
        if (c == '|' || c == '_') {
            return false;
        }
    }
    return true;
}

void agregarMateria() {
    if (numMaterias >= MAX_MATERIAS) {
        cout << "Error: No se pueden agregar mas materias.\n";
        return;
    }

    Materia materia;
    cout << "Ingrese la clave de la materia: ";
    cin >> materia.clave;
    if (!validarEntrada(materia.clave)) {
        cout << "Error: La clave contiene caracteres no permitidos.\n";
        return;
    }

    cout << "Ingrese el nombre de la materia: ";
    cin.ignore();
    getline(cin, materia.nombre);
    if (!validarEntrada(materia.nombre)) {
        cout << "Error: El nombre contiene caracteres no permitidos.\n";
        return;
    }

    materia.numPrerrequisitos = 0;
    cout << "Ingrese los prerrequisitos (maximo " << MAX_PRERREQUISITOS << ", ingrese '_' para ninguno):\n";
    for (int i = 0; i < MAX_PRERREQUISITOS; i++) {
        string prerrequisito;
        cout << "Prerrequisito " << (i + 1) << ": ";
        cin >> prerrequisito;

        if (prerrequisito == "_") break;

        if (!validarEntrada(prerrequisito)) {
            cout << "Error: El prerrequisito contiene caracteres no permitidos.\n";
            return;
        }

        materia.prerrequisitos[materia.numPrerrequisitos++] = prerrequisito;
    }

    listaMaterias[numMaterias++] = materia;
    cout << "Materia agregada correctamente.\n";
}

void menu(const string& nombreArchivo) {
    int opcion;
    do {
        limpiarPantalla();
        cout << "Menu Principal:\n";
        cout << "1. Listar registros\n";
        cout << "2. Agregar nueva materia\n";
        cout << "3. Guardar cambios\n";
        cout << "4. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            listarMaterias();
            system("pause");
            break;
        case 2:
            agregarMateria();
            system("pause");
            break;
        case 3:
            guardarMateriasEnArchivo(nombreArchivo);
            system("pause");
            break;
        case 4:
            cout << "Saliendo del programa...\n";
            break;
        default:
            cout << "Opcion invalida. Intente de nuevo.\n";
            system("pause");
            break;
        }
    } while (opcion != 4);
}

int main() {
    const string nombreArchivo = "Materia.txt";
    cargarMateriasDesdeArchivo(nombreArchivo);
    menu(nombreArchivo);
    return 0;
}
