#include <iostream>
#include "Fecha.h"

using namespace std;

void mostrarMenu() {
    cout << "\nMenu de Fecha\n";
    cout << "1. Modificar Anio\n";
    cout << "2. Modificar Mes\n";
    cout << "3. Modificar Dia\n";
    cout << "4. Mostrar Fecha Actual\n";
    cout << "5. Salir\n";
    cout << "Seleccione una opcion: ";
}

int main() {
    Fecha fecha(2000, 1, 1); // Modificar con la fecha de nacimiento del alumno
    int opcion;
    do {
        mostrarMenu();
        cin >> opcion;

        switch (opcion) {
            case 1: {
                int nuevoAnio;
                cout << "Ingrese el nuevo anio: ";
                cin >> nuevoAnio;
                fecha.fijaAnio(nuevoAnio);
                break;
            }
            case 2: {
                int nuevoMes;
                cout << "Ingrese el nuevo mes: ";
                cin >> nuevoMes;
                fecha.fijaMes(nuevoMes);
                break;
            }
            case 3: {
                int nuevoDia;
                cout << "Ingrese el nuevo dia: ";
                cin >> nuevoDia;
                fecha.fijaDia(nuevoDia);
                break;
            }
            case 4:
                cout << "Fecha Actual: " << fecha.dameAnio() << "/" << fecha.dameMes() << "/" << fecha.dameDia() << endl;
                break;
            case 5:
                cout << "Saliendo del programa.\n";
                break;
            default:
                cout << "Opcion no valida.\n";
        }
    } while (opcion != 5);

    return 0;
}
