#ifndef FECHA_H
#define FECHA_H

class Fecha {
private:
    int anio;
    int mes;
    int dia;

    bool esBisiesto(int anio) const {
        return (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);
    }

    bool esFechaValida(int anio, int mes, int dia) const {
        if (mes < 1 || mes > 12) return false;
        if (dia < 1) return false;

        switch (mes) {
            case 2:
                return dia <= (esBisiesto(anio) ? 29 : 28);
            case 4: case 6: case 9: case 11:
                return dia <= 30;
            default:
                return dia <= 31;
        }
    }

public:
    Fecha(int anio = 2000, int mes = 1, int dia = 1) : anio(anio), mes(mes), dia(dia) {
        if (!esFechaValida(anio, mes, dia)) {
            this->anio = 2000;
            this->mes = 1;
            this->dia = 1;
        }
    }

    int dameAnio() const { return anio; }
    int dameMes() const { return mes; }
    int dameDia() const { return dia; }

    void fijaAnio(int nuevoAnio) {
        if (esFechaValida(nuevoAnio, mes, dia)) anio = nuevoAnio;
    }

    void fijaMes(int nuevoMes) {
        if (esFechaValida(anio, nuevoMes, dia)) mes = nuevoMes;
    }

    void fijaDia(int nuevoDia) {
        if (esFechaValida(anio, mes, nuevoDia)) dia = nuevoDia;
    }
};

#endif
