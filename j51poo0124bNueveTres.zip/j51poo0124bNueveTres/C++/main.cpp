#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h> // Para usar system("cls")

#define MAX_ALUMNOS 100

typedef struct {
    char nombre[50];
    char matricula[15];
    float promedio;
    int anio;
    bool libre; // Indica si el registro esta vacio
} Alumno;

void inicializarRegistros(Alumno arr[], int tam) {
    for (int i = 0; i < tam; i++) {
        arr[i].libre = true;
    }
}

void limpiarConsola() {
    system("cls"); // Comando para limpiar la consola en Windows
}

void agregarAlumno(Alumno arr[], int tam) {
    limpiarConsola();
    for (int i = 0; i < tam; i++) {
        if (arr[i].libre) {
            printf("Nombre: ");
            scanf(" %[^\n]", arr[i].nombre);
            printf("Matricula: ");
            scanf("%s", arr[i].matricula);
            printf("Promedio: ");
            scanf("%f", &arr[i].promedio);
            printf("Anio: ");
            scanf("%d", &arr[i].anio);
            arr[i].libre = false;
            printf("Alumno agregado correctamente.\n");
            return;
        }
    }
    printf("No hay espacio para mas alumnos.\n");
}

void listarAlumnos(Alumno arr[], int tam) {
    limpiarConsola();
    printf("\nAlumnos registrados:\n");
    for (int i = 0; i < tam; i++) {
        if (!arr[i].libre) {
            printf("Nombre: %s, Matricula: %s, Promedio: %.2f, Anio: %d\n",
                   arr[i].nombre, arr[i].matricula, arr[i].promedio, arr[i].anio);
        }
    }
}

void buscarAlumno(Alumno arr[], int tam) {
    limpiarConsola();
    char buscado[50];
    printf("Ingrese nombre o parte del nombre a buscar: ");
    scanf(" %[^\n]", buscado);

    bool encontrado = false;
    for (int i = 0; i < tam; i++) {
        if (!arr[i].libre && strstr(arr[i].nombre, buscado)) {
            printf("Encontrado: %s, Matricula: %s\n", arr[i].nombre, arr[i].matricula);
            encontrado = true;
        }
    }
    if (!encontrado) {
        printf("No se encontro el alumno.\n");
    }
}

void modificarAlumno(Alumno arr[], int tam) {
    limpiarConsola();
    int indice;
    printf("Ingrese el indice del alumno a modificar (1 a %d): ", tam);
    scanf("%d", &indice);
    indice -= 1;

    if (indice >= 0 && indice < tam && !arr[indice].libre) {
        printf("Nuevo promedio: ");
        scanf("%f", &arr[indice].promedio);
        printf("Alumno modificado correctamente.\n");
    } else {
        printf("Indice invalido o alumno no encontrado.\n");
    }
}

void eliminarAlumno(Alumno arr[], int tam) {
    limpiarConsola();
    int indice;
    printf("Ingrese el indice del alumno a eliminar (1 a %d): ", tam);
    scanf("%d", &indice);
    indice -= 1;

    if (indice >= 0 && indice < tam && !arr[indice].libre) {
        arr[indice].libre = true;
        printf("Alumno eliminado correctamente.\n");
    } else {
        printf("Indice invalido o alumno no encontrado.\n");
    }
}

int main() {
    Alumno alumnos[MAX_ALUMNOS];
    inicializarRegistros(alumnos, MAX_ALUMNOS);

    int opcion;
    do {
        printf("\nMenu:\n1. Agregar Alumno\n2. Listar Alumnos\n3. Buscar Alumno\n4. Modificar Alumno\n5. Eliminar Alumno\n6. Salir\n");
        printf("Seleccione una opcion: ");
        scanf("%d", &opcion);

        limpiarConsola();
        switch(opcion) {
            case 1: agregarAlumno(alumnos, MAX_ALUMNOS); break;
            case 2: listarAlumnos(alumnos, MAX_ALUMNOS); break;
            case 3: buscarAlumno(alumnos, MAX_ALUMNOS); break;
            case 4: modificarAlumno(alumnos, MAX_ALUMNOS); break;
            case 5: eliminarAlumno(alumnos, MAX_ALUMNOS); break;
            case 6: printf("Saliendo del programa.\n"); break;
            default: printf("Opcion no valida.\n");
        }
    } while (opcion != 6);

    return 0;
}

