#ifndef CLASES_H
#define CLASES_H

#include <string>
#include <iostream>

class Carrera {
private:
    int idCarrera;
    std::string nombreCarrera;

public:
    // Constructor con parámetros
    Carrera(int id, std::string nombre) : idCarrera(id), nombreCarrera(nombre) {}

    // Métodos getters
    int dameIdCarrera() const { return idCarrera; }
    std::string dameNombreCarrera() const { return nombreCarrera; }
};

class Alumno {
private:
    std::string nombreAlumno;
    int edadAlumno;
    float promedioAlumno;
    int idCarreraAlumno;

public:
    // Constructor con parámetros
    Alumno(std::string nombre, int edad, float promedio, int idCarrera)
        : nombreAlumno(nombre), edadAlumno(edad), promedioAlumno(promedio), idCarreraAlumno(idCarrera) {}

    // Métodos getters
    std::string dameNombre() const { return nombreAlumno; }
    int dameEdad() const { return edadAlumno; }
    float damePromedio() const { return promedioAlumno; }
    int dameIdCarreraAlumno() const { return idCarreraAlumno; }
};

#endif // CLASES_H
