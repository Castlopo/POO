#include <iostream>
#include <string>
#include "clases.h"

using namespace std;

Carrera crearCarrera(int id, const string& nombre) {
    return Carrera(id, nombre);
}

Alumno crearAlumno(const string& nombre, int edad, float promedio, int idCarrera) {
    return Alumno(nombre, edad, promedio, idCarrera);
}

int main() {
    int idCarrera;
    string nombreCarrera;

    cout << "Introduce el ID de la carrera: ";
    cin >> idCarrera;
    cin.ignore();
    cout << "Introduce el nombre de la carrera: ";
    getline(cin, nombreCarrera);

    Carrera carrera = crearCarrera(idCarrera, nombreCarrera);

    string nombreAlumno;
    int edadAlumno;
    float promedioAlumno;

    cout << "Introduce el nombre del alumno: ";
    getline(cin, nombreAlumno);
    cout << "Introduce la edad del alumno: ";
    cin >> edadAlumno;
    cout << "Introduce el promedio del alumno: ";
    cin >> promedioAlumno;

    Alumno alumno = crearAlumno(nombreAlumno, edadAlumno, promedioAlumno, carrera.dameIdCarrera());

    cout << "\nDatos del Alumno y Carrera:" << endl;
    cout << "ID de la Carrera: " << carrera.dameIdCarrera() << endl;
    cout << "Nombre de la Carrera: " << carrera.dameNombreCarrera() << endl;
    cout << "Nombre del Alumno: " << alumno.dameNombre() << endl;
    cout << "Edad del Alumno: " << alumno.dameEdad() << endl;
    cout << "Promedio del Alumno: " << alumno.damePromedio() << endl;

    return 0;
}
