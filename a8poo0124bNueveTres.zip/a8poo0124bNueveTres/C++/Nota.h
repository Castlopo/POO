// Nota.h
#ifndef NOTA_H
#define NOTA_H

#include <iostream>  
#include <string>

class Nota {
private:
    int id;
    std::string titulo;
    std::string contenido;

public:
    Nota(int id = 0, const std::string& titulo = "Sin titulo", const std::string& contenido = "Sin contenido")
        : id(id), titulo(titulo), contenido(contenido) {}

    bool setId(int nuevoId) {
        if (nuevoId > 0) {
            id = nuevoId;
            return true;
        }
        return false;
    }

    bool setTitulo(const std::string& nuevoTitulo) {
        if (!nuevoTitulo.empty()) {
            titulo = nuevoTitulo;
            return true;
        }
        return false;
    }

    bool setContenido(const std::string& nuevoContenido) {
        if (!nuevoContenido.empty()) {
            contenido = nuevoContenido;
            return true;
        }
        return false;
    }

    int getId() const { return id; }
    std::string getTitulo() const { return titulo; }
    std::string getContenido() const { return contenido; }

    void mostrarDetalles() const {
        std::cout << "ID: " << id << ", Titulo: " << titulo << ", Contenido: " << contenido << std::endl;
    }
};

#endif
