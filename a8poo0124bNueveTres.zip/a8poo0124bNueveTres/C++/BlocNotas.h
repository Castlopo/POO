#ifndef BLOCNOTAS_H
#define BLOCNOTAS_H

#include "Nota.h"
#include <iostream>
using namespace std;

class BlocNotas {
private:
    Nota* notas[100];
    int cantidad;

    int buscarIndicePorId(int id) const {
        for (int i = 0; i < cantidad; ++i) {
            if (notas[i]->getId() == id)
                return i;
        }
        return -1;
    }

public:
    BlocNotas() : cantidad(0) {}

    ~BlocNotas() {
        for (int i = 0; i < cantidad; ++i) {
            delete notas[i];
        }
    }

    void agregarNota(int id, const string& titulo, const string& contenido) {
        if (cantidad >= 100) {
            cout << "Error: No se pueden agregar mas notas.\n";
            return;
        }
        if (buscarIndicePorId(id) != -1) {
            cout << "Error: Ya existe una nota con el ID " << id << ".\n";
            return;
        }
        notas[cantidad++] = new Nota(id, titulo, contenido);
        cout << "Nota agregada exitosamente.\n";
    }

    void listarNotas() const {
        if (cantidad == 0) {
            cout << "No hay notas registradas.\n";
            return;
        }
        cout << "Lista de notas:\n";
        for (int i = 0; i < cantidad; ++i) {
            cout << "ID: " << notas[i]->getId() << ", Titulo: " << notas[i]->getTitulo() << endl;
        }
    }

    void mostrarDetalles(int id) const {
        int indice = buscarIndicePorId(id);
        if (indice != -1) {
            notas[indice]->mostrarDetalles();
        } else {
            cout << "Error: No se encontro una nota con el ID " << id << ".\n";
        }
    }

    void modificarNota(int id, const string& nuevoTitulo, const string& nuevoContenido) {
        int indice = buscarIndicePorId(id);
        if (indice != -1) {
            notas[indice]->setTitulo(nuevoTitulo);
            notas[indice]->setContenido(nuevoContenido);
            cout << "Nota modificada exitosamente.\n";
        } else {
            cout << "Error: No se encontro una nota con el ID " << id << ".\n";
        }
    }

    void eliminarNota(int id) {
        int indice = buscarIndicePorId(id);
        if (indice != -1) {
            delete notas[indice];
            for (int i = indice; i < cantidad - 1; ++i) {
                notas[i] = notas[i + 1];
            }
            cantidad--;
            cout << "Nota eliminada exitosamente.\n";
        } else {
            cout << "Error: No se encontro una nota con el ID " << id << ".\n";
        }
    }
};

#endif
