#include "BlocNotas.h"

int main() {
    BlocNotas bloc;
    int opcion;

    do {
        cout << "\n--- MENU BLOC DE NOTAS ---\n";
        cout << "1. Agregar nota\n";
        cout << "2. Listar notas\n";
        cout << "3. Mostrar detalles de una nota\n";
        cout << "4. Modificar una nota\n";
        cout << "5. Eliminar nota\n";
        cout << "6. Guardar cambios (en construccion)\n";
        cout << "7. Regresar al menu anterior\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1: {
                int id;
                string titulo, contenido;
                cout << "Ingrese ID: ";
                cin >> id;
                cin.ignore();
                cout << "Ingrese Titulo: ";
                getline(cin, titulo);
                cout << "Ingrese Contenido: ";
                getline(cin, contenido);
                bloc.agregarNota(id, titulo, contenido);
                break;
            }
            case 2:
                bloc.listarNotas();
                break;
            case 3: {
                int id;
                cout << "Ingrese ID de la nota: ";
                cin >> id;
                bloc.mostrarDetalles(id);
                break;
            }
            case 4: {
                int id;
                string nuevoTitulo, nuevoContenido;
                cout << "Ingrese ID de la nota: ";
                cin >> id;
                cin.ignore();
                cout << "Ingrese nuevo Titulo: ";
                getline(cin, nuevoTitulo);
                cout << "Ingrese nuevo Contenido: ";
                getline(cin, nuevoContenido);
                bloc.modificarNota(id, nuevoTitulo, nuevoContenido);
                break;
            }
            case 5: {
                int id;
                cout << "Ingrese ID de la nota a eliminar: ";
                cin >> id;
                bloc.eliminarNota(id);
                break;
            }
            case 6:
                cout << "Guardando cambios (en construccion)...\n";
                break;
            case 7:
                cout << "Regresando al menu anterior...\n";
                break;
            default:
                cout << "Opcion invalida.\n";
        }
    } while (opcion != 7);

    return 0;
}
