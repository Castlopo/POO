/*
Nick Name: NueveTres
Tiempo: 00:56
Act: j53
*/
#include <iostream>
#include <string>
#include <vector>

using namespace std;

typedef struct {
    int id;
    string nombre;
    int edad;
    float promedio;
    string grado;
} Alumno;

void capturarAlumno(vector<Alumno>& alumnos);
void listarAlumnos(const vector<Alumno>& alumnos);
void actualizarAlumno(vector<Alumno>& alumnos);
void eliminarAlumno(vector<Alumno>& alumnos);
int buscarIndicePorID(const vector<Alumno>& alumnos, int id);

int main() {
    vector<Alumno> alumnos;
    int opcion;

    do {
        cout << "\nMenu ABC de Alumnos:\n";
        cout << "1. Capturar Alumno\n";
        cout << "2. Listar Alumnos\n";
        cout << "3. Actualizar Alumno\n";
        cout << "4. Eliminar Alumno\n";
        cout << "5. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        cin.ignore();

        switch (opcion) {
            case 1:
                capturarAlumno(alumnos);
                break;
            case 2:
                listarAlumnos(alumnos);
                break;
            case 3:
                actualizarAlumno(alumnos);
                break;
            case 4:
                eliminarAlumno(alumnos);
                break;
            case 5:
                cout << "Saliendo del programa.\n";
                break;
            default:
                cout << "Opcion no valida. Intente de nuevo.\n";
        }
    } while (opcion != 5);

    return 0;
}

void capturarAlumno(vector<Alumno>& alumnos) {
    Alumno nuevoAlumno;
    nuevoAlumno.id = alumnos.size() + 1;

    cout << "Ingrese el nombre del alumno: ";
    getline(cin, nuevoAlumno.nombre);
    cout << "Ingrese la edad del alumno: ";
    cin >> nuevoAlumno.edad;
    cout << "Ingrese el promedio del alumno: ";
    cin >> nuevoAlumno.promedio;
    cin.ignore();
    cout << "Ingrese el grado del alumno: ";
    getline(cin, nuevoAlumno.grado);

    alumnos.push_back(nuevoAlumno);
    cout << "Alumno capturado exitosamente.\n";
}

void listarAlumnos(const vector<Alumno>& alumnos) {
    if (!alumnos.empty()) {
        for (const auto& alumno : alumnos) {
            cout << "\nID: " << alumno.id
                 << "\nNombre: " << alumno.nombre
                 << "\nEdad: " << alumno.edad
                 << "\nPromedio: " << alumno.promedio
                 << "\nGrado: " << alumno.grado << "\n";
        }
    } else {
        cout << "No hay alumnos registrados.\n";
    }
}

void actualizarAlumno(vector<Alumno>& alumnos) {
    int id;
    cout << "Ingrese el ID del alumno a actualizar: ";
    cin >> id;
    cin.ignore();

    int indice = buscarIndicePorID(alumnos, id);
    if (indice != -1) {
        cout << "Ingrese el nuevo nombre del alumno: ";
        getline(cin, alumnos[indice].nombre);
        cout << "Ingrese la nueva edad del alumno: ";
        cin >> alumnos[indice].edad;
        cout << "Ingrese el nuevo promedio del alumno: ";
        cin >> alumnos[indice].promedio;
        cin.ignore();
        cout << "Ingrese el nuevo grado del alumno: ";
        getline(cin, alumnos[indice].grado);
        cout << "Alumno actualizado exitosamente.\n";
    } else {
        cout << "ID no encontrado.\n";
    }
}

void eliminarAlumno(vector<Alumno>& alumnos) {
    int id;
    cout << "Ingrese el ID del alumno a eliminar: ";
    cin >> id;
    cin.ignore();

    int indice = buscarIndicePorID(alumnos, id);
    if (indice != -1) {
        alumnos.erase(alumnos.begin() + indice);
        for (size_t i = indice; i < alumnos.size(); ++i) {
            alumnos[i].id = i + 1;
        }
        cout << "Alumno eliminado exitosamente.\n";
    } else {
        cout << "ID no encontrado.\n";
    }
}

int buscarIndicePorID(const vector<Alumno>& alumnos, int id) {
    for (size_t i = 0; i < alumnos.size(); ++i) {
        if (alumnos[i].id == id) {
            return i;
        }
    }
    return -1;
}
