#include <iostream>
#include <string>
using namespace std;

class Fecha {
private:
    int dia;
    int mes;
    int anio;

public:
    Fecha() : dia(1), mes(1), anio(2000) {}

    int getDia() const { return dia; }
    void setDia(int d) { dia = d; }

    int getMes() const { return mes; }
    void setMes(int m) { mes = m; }

    int getAnio() const { return anio; }
    void setAnio(int a) { anio = a; }

    void imprimirFecha() const {
        cout << dia << "/" << mes << "/" << anio;
    }
};

class Persona {
private:
    string nombre;
    int edad;
    Fecha fechaNacimiento;

public:
    Persona() : nombre("Sin Nombre"), edad(0), fechaNacimiento() {}

    string getNombre() const { return nombre; }
    void setNombre(const string& n) { nombre = n; }

    int getEdad() const { return edad; }
    void setEdad(int e) { edad = e; }

    Fecha getFechaNacimiento() const { return fechaNacimiento; }
    void setFechaNacimiento(const Fecha& f) { fechaNacimiento = f; }

    void mostrarDatos() const {
        cout << "Nombre: " << nombre << endl;
        cout << "Edad: " << edad << endl;
        cout << "Fecha de Nacimiento: ";
        fechaNacimiento.imprimirFecha();
        cout << endl;
    }

    void solicitarDatos() {
        cout << "Ingrese nombre: ";
        getline(cin, nombre);

        cout << "Ingrese edad: ";
        cin >> edad;

        int dia, mes, anio;
        cout << "Ingrese fecha de nacimiento (DD MM AAAA): ";
        cin >> dia >> mes >> anio;

        Fecha nuevaFecha;
        nuevaFecha.setDia(dia);
        nuevaFecha.setMes(mes);
        nuevaFecha.setAnio(anio);

        setFechaNacimiento(nuevaFecha);

        cin.ignore();
    }
};

int main() {
    Persona persona;

    cout << "Datos por defecto de la persona:" << endl;
    persona.mostrarDatos();

    cout << "\nPor favor, ingrese nuevos datos para la persona:" << endl;
    persona.solicitarDatos();

    cout << "\nDatos actualizados de la persona:" << endl;
    persona.mostrarDatos();

    return 0;
}

