/*
Autor: NueveTres
Actividad: r3
Tiempo=02:30
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_DISC_COUNT 5
#define PROMPT_DISCS "Ingrese la cantidad de discos a mover (maximo "
#define ERROR_DISCS "Numero de discos invalido. Intente con un numero entre 1 y "
#define INITIAL_STATE "Estado inicial de las torres:"
#define MOVE_PROMPT "Mover el disco superior de la torre "
#define FINAL_PROMPT "Se realizaron en total "
#define END_MESSAGE "Presione enter para finalizar..."
#define SOURCE_TOWER 0
#define TARGET_TOWER 2
#define AUXILIARY_TOWER 1


void showTowerStates(int towers[3][MAX_DISC_COUNT], int top[3]);
void solveHanoi(int discCount, int source, int target, int auxiliary, int towers[3][MAX_DISC_COUNT], int top[3]);

int main() {
    printf("TORRES DE HANOI\n");
    printf("Este programa resuelve el problema de las Torres de Hanoi para un maximo de %d discos.\n", MAX_DISC_COUNT);

    int discCount;
    printf(PROMPT_DISCS "%d): ", MAX_DISC_COUNT);
    scanf("%d", &discCount);

    if (discCount < 1 || discCount > MAX_DISC_COUNT) {
        printf(ERROR_DISCS "%d.\n", MAX_DISC_COUNT);
        return 1;
    }

    int towers[3][MAX_DISC_COUNT] = {0};
    int top[3] = {0};
    for (int i = 0; i < discCount; i++) {
        towers[SOURCE_TOWER][i] = discCount - i;
    }
    top[SOURCE_TOWER] = discCount;

    printf(INITIAL_STATE "\n");
    showTowerStates(towers, top);

    solveHanoi(discCount, SOURCE_TOWER, TARGET_TOWER, AUXILIARY_TOWER, towers, top);

    printf(FINAL_PROMPT "%d movimientos.\n", (1 << discCount) - 1);
    printf(END_MESSAGE "\n");
    getchar();
    getchar();

    return 0;
}

void showTowerStates(int towers[3][MAX_DISC_COUNT], int top[3]) {
    for (int i = 0; i < 3; i++) {
        printf("Torre%d: ", i + 1);
        for (int j = 0; j < top[i]; j++) {
            printf("%d ", towers[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

void solveHanoi(int discCount, int source, int target, int auxiliary, int towers[3][MAX_DISC_COUNT], int top[3]) {
    if (discCount == 1) {
        int disc = towers[source][--top[source]];
        towers[target][top[target]++] = disc;

        printf(MOVE_PROMPT "%d a la torre %d\n", source + 1, target + 1);
        showTowerStates(towers, top);
        return;
    }

    solveHanoi(discCount - 1, source, auxiliary, target, towers, top);
    solveHanoi(1, source, target, auxiliary, towers, top);
    solveHanoi(discCount - 1, auxiliary, target, source, towers, top);
}
