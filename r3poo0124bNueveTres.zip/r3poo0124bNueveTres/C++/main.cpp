/*
Autor: NueveTres
Actividad: r3
Tiempo=02:30
*/

#include <iostream>
#include <cstdlib>
using namespace std;


const int MAX_DISC_COUNT = 5;
const string PROMPT_DISCS = "Ingrese la cantidad de discos a mover (maximo ";
const string ERROR_DISCS = "Numero de discos invalido. Intente con un numero entre 1 y ";
const string INITIAL_STATE = "Estado inicial de las torres:";
const string MOVE_PROMPT = "Mover el disco superior de la torre ";
const string FINAL_PROMPT = "Se realizaron en total ";
const string END_MESSAGE = "Presione enter para finalizar...";
const int SOURCE_TOWER = 0;
const int TARGET_TOWER = 2;
const int AUXILIARY_TOWER = 1;


void showTowerStates(int towers[3][MAX_DISC_COUNT], int top[3]);
void solveHanoi(int discCount, int source, int target, int auxiliary, int towers[3][MAX_DISC_COUNT], int top[3]);

int main() {
    cout << "TORRES DE HANOI" << endl;
    cout << "Este programa resuelve el problema de las Torres de Hanoi para un maximo de " << MAX_DISC_COUNT << " discos." << endl;

    int discCount;
    cout << PROMPT_DISCS << MAX_DISC_COUNT << "): ";
    cin >> discCount;

    if (discCount < 1 || discCount > MAX_DISC_COUNT) {
        cout << ERROR_DISCS << MAX_DISC_COUNT << "." << endl;
        return 1;
    }

    int towers[3][MAX_DISC_COUNT] = {0};
    int top[3] = {0};
    for (int i = 0; i < discCount; i++) {
        towers[SOURCE_TOWER][i] = discCount - i;
    }
    top[SOURCE_TOWER] = discCount;

    cout << INITIAL_STATE << endl;
    showTowerStates(towers, top);

    solveHanoi(discCount, SOURCE_TOWER, TARGET_TOWER, AUXILIARY_TOWER, towers, top);

    cout << FINAL_PROMPT << (1 << discCount) - 1 << " movimientos." << endl;
    cout << END_MESSAGE << endl;
    cin.ignore();
    cin.get();

    return 0;
}

void showTowerStates(int towers[3][MAX_DISC_COUNT], int top[3]) {
    for (int i = 0; i < 3; i++) {
        cout << "Torre" << i + 1 << ": ";
        for (int j = 0; j < top[i]; j++) {
            cout << towers[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

void solveHanoi(int discCount, int source, int target, int auxiliary, int towers[3][MAX_DISC_COUNT], int top[3]) {
    if (discCount == 1) {
        int disc = towers[source][--top[source]];
        towers[target][top[target]++] = disc;

        cout << MOVE_PROMPT << source + 1 << " a la torre " << target + 1 << endl;
        showTowerStates(towers, top);
        return;
    }

    solveHanoi(discCount - 1, source, auxiliary, target, towers, top);
    solveHanoi(1, source, target, auxiliary, towers, top);
    solveHanoi(discCount - 1, auxiliary, target, source, towers, top);
}
