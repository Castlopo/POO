
#ifndef TAREA_H
#define TAREA_H

#include <string>
using namespace std;

class Tarea {
private:
    string nombre;
    string descripcion;
    string fechaEntrega;
    string estatus;

public:
    Tarea(string nombre = "", string descripcion = "", string fecha = "", string estatus = "");

    void setNombre(const string& nombre);
    void setDescripcion(const string& descripcion);
    void setFechaEntrega(const string& fecha);
    void setEstatus(const string& estatus);

    string getNombre() const;
    string getDescripcion() const;
    string getFechaEntrega() const;
    string getEstatus() const;

    void mostrarDetalles() const;
};

void gestionarTareas();

#endif
    