
#include "Tarea.h"
#include <iostream>
#include <vector>
using namespace std;

vector<Tarea*> listaTareas;

Tarea::Tarea(string nombre, string descripcion, string fecha, string estatus)
    : nombre(nombre), descripcion(descripcion), fechaEntrega(fecha), estatus(estatus) {}

void Tarea::setNombre(const string& n) { nombre = n; }
void Tarea::setDescripcion(const string& d) { descripcion = d; }
void Tarea::setFechaEntrega(const string& f) { fechaEntrega = f; }
void Tarea::setEstatus(const string& e) { estatus = e; }

string Tarea::getNombre() const { return nombre; }
string Tarea::getDescripcion() const { return descripcion; }
string Tarea::getFechaEntrega() const { return fechaEntrega; }
string Tarea::getEstatus() const { return estatus; }

void Tarea::mostrarDetalles() const {
    cout << "Nombre: " << nombre << "\n";
    cout << "Descripción: " << descripcion << "\n";
    cout << "Fecha de entrega: " << fechaEntrega << "\n";
    cout << "Estatus: " << estatus << "\n";
}

void gestionarTareas() {
    cout << "Gestión de tareas aún no implementada completamente.\n";
}
    