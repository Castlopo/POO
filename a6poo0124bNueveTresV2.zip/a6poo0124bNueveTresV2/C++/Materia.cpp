
#include "Materia.h"
#include <iostream>
#include <vector>
using namespace std;

vector<Materia*> listaMaterias;

Materia::Materia(string nombre, string codigo, int creditos, string profesor)
    : nombre(nombre), codigo(codigo), creditos(creditos), profesor(profesor) {}

void Materia::setNombre(const string& n) { nombre = n; }
void Materia::setCodigo(const string& c) { codigo = c; }
void Materia::setCreditos(int cr) { creditos = cr; }
void Materia::setProfesor(const string& p) { profesor = p; }

string Materia::getNombre() const { return nombre; }
string Materia::getCodigo() const { return codigo; }
int Materia::getCreditos() const { return creditos; }
string Materia::getProfesor() const { return profesor; }

void Materia::mostrarDetalles() const {
    cout << "Nombre: " << nombre << "\n";
    cout << "Código: " << codigo << "\n";
    cout << "Créditos: " << creditos << "\n";
    cout << "Profesor: " << profesor << "\n";
}

void gestionarMaterias() {
    cout << "Gestión de materias aún no implementada completamente.\n";
}
    