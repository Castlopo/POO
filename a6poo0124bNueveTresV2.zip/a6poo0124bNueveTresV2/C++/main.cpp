/*
NickName:NueveTres
Codigio: a5
Tiempo: 02:36
*/
#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

using namespace std;

class Materia {
private:
    string nombre;
    string codigo;
    int creditos;
    string profesor;

public:
    Materia(string nombre = "", string codigo = "", int creditos = 0, string profesor = "")
        : nombre(nombre), codigo(codigo), creditos(creditos), profesor(profesor) {}

    void fijaNombre(string n) { nombre = n; }
    void fijaCodigo(string c) { codigo = c; }
    void fijaCreditos(int cr) { creditos = cr; }
    void fijaProfesor(string p) { profesor = p; }

    string dameNombre() const { return nombre; }
    string dameCodigo() const { return codigo; }
    int dameCreditos() const { return creditos; }
    string dameProfesor() const { return profesor; }

    void mostrarDetalles() const {
        cout << "Nombre: " << nombre << "\n"
             << "Codigo: " << codigo << "\n"
             << "Creditos: " << creditos << "\n"
             << "Profesor: " << profesor << "\n";
    }
};

const int MAX_MATERIAS = 10;
Materia* materias[MAX_MATERIAS];
int contadorMaterias = 0;

void agregarMateria() {
    if (contadorMaterias >= MAX_MATERIAS) {
        cout << "No se pueden agregar mas materias. Capacidad maxima alcanzada.\n";
        return;
    }

    string nombre, codigo, profesor;
    int creditos;

    cout << "Ingrese el nombre de la materia: ";
    cin.ignore();
    getline(cin, nombre);
    cout << "Ingrese el codigo de la materia: ";
    getline(cin, codigo);
    cout << "Ingrese los creditos de la materia: ";
    cin >> creditos;
    cout << "Ingrese el nombre del profesor: ";
    cin.ignore();
    getline(cin, profesor);

    materias[contadorMaterias] = new Materia(nombre, codigo, creditos, profesor);
    contadorMaterias++;
    cout << "Materia agregada exitosamente.\n";
}

void listarMaterias() {
    if (contadorMaterias == 0) {
        cout << "No hay materias registradas.\n";
        return;
    }

    for (int i = 0; i < contadorMaterias; i++) {
        cout << i + 1 << ". " << materias[i]->dameNombre() << " (" << materias[i]->dameCodigo() << ")\n";
    }
}

void mostrarDetallesMateria() {
    if (contadorMaterias == 0) {
        cout << "No hay materias registradas.\n";
        return;
    }

    int indice;
    listarMaterias();
    cout << "Seleccione el numero de la materia: ";
    cin >> indice;

    if (indice < 1 || indice > contadorMaterias) {
        cout << "Seleccion invalida.\n";
        return;
    }

    materias[indice - 1]->mostrarDetalles();
}

void modificarMateria() {
    if (contadorMaterias == 0) {
        cout << "No hay materias registradas.\n";
        return;
    }

    int indice;
    listarMaterias();
    cout << "Seleccione el numero de la materia a modificar: ";
    cin >> indice;

    if (indice < 1 || indice > contadorMaterias) {
        cout << "Seleccion invalida.\n";
        return;
    }

    Materia* materia = materias[indice - 1];
    string nombre, codigo, profesor;
    int creditos;

    cout << "Ingrese el nuevo nombre (actual: " << materia->dameNombre() << "): ";
    cin.ignore();
    getline(cin, nombre);
    cout << "Ingrese el nuevo codigo (actual: " << materia->dameCodigo() << "): ";
    getline(cin, codigo);
    cout << "Ingrese los nuevos creditos (actual: " << materia->dameCreditos() << "): ";
    cin >> creditos;
    cout << "Ingrese el nuevo nombre del profesor (actual: " << materia->dameProfesor() << "): ";
    cin.ignore();
    getline(cin, profesor);

    materia->fijaNombre(nombre);
    materia->fijaCodigo(codigo);
    materia->fijaCreditos(creditos);
    materia->fijaProfesor(profesor);
    cout << "Materia modificada exitosamente.\n";
}

void eliminarMateria() {
    if (contadorMaterias == 0) {
        cout << "No hay materias registradas.\n";
        return;
    }

    int indice;
    listarMaterias();
    cout << "Seleccione el numero de la materia a eliminar: ";
    cin >> indice;

    if (indice < 1 || indice > contadorMaterias) {
        cout << "Seleccion invalida.\n";
        return;
    }

    delete materias[indice - 1];

    for (int i = indice; i < contadorMaterias; i++) {
        materias[i - 1] = materias[i];
    }
    contadorMaterias--;
    cout << "Materia eliminada exitosamente.\n";
}

void menuPrincipal() {
    int opcion;

    do {
        system("cls");
        cout << "\nMenu Principal:\n"
             << "1. Evaluacion del Curso\n"
             << "2. Gestion de Materias\n"
             << "3. Salir\n"
             << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Funcionalidad de Evaluacion del Curso aun no implementada.\n";
                cout << "Presione Enter para continuar...";
                cin.ignore();
                getchar();
                break;
            case 2: {
                int opcionGestion;
                do {
                    system("cls");
                    cout << "\nGestion de Materias:\n"
                         << "1. Agregar materia\n"
                         << "2. Listar materias\n"
                         << "3. Mostrar detalles de una materia\n"
                         << "4. Modificar una materia\n"
                         << "5. Eliminar materia\n"
                         << "6. Guardar cambios (en construccion)\n"
                         << "7. Regresar al menu anterior\n"
                         << "Seleccione una opcion: ";
                    cin >> opcionGestion;

                    switch (opcionGestion) {
                        case 1:
                            agregarMateria();
                            break;
                        case 2:
                            listarMaterias();
                            break;
                        case 3:
                            mostrarDetallesMateria();
                            break;
                        case 4:
                            modificarMateria();
                            break;
                        case 5:
                            eliminarMateria();
                            break;
                        case 6:
                            cout << "Funcionalidad en construccion.\n";
                            break;
                        case 7:
                            break;
                        default:
                            cout << "Opcion invalida.\n";
                    }
                } while (opcionGestion != 7);
                break;
            }
            case 3:
                cout << "Saliendo del programa...\n";
                break;
            default:
                cout << "Opcion invalida.\n";
        }
    } while (opcion != 3);
}

void liberarMemoria() {
    for (int i = 0; i < contadorMaterias; i++) {
        delete materias[i];
    }
}

int main() {
    menuPrincipal();
    liberarMemoria();
    return 0;
}
