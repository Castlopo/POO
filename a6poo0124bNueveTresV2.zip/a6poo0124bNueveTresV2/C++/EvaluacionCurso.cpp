
#include "EvaluacionCurso.h"
#include <iostream>
using namespace std;

EvaluacionCurso::EvaluacionCurso(string nombre, float promedio, float maxima, float minima)
    : nombreCurso(nombre), calificacionPromedio(promedio), calificacionMaxima(maxima), calificacionMinima(minima) {}

void EvaluacionCurso::mostrarDetalles() {
    cout << "Nombre del curso: " << nombreCurso << "\n";
    cout << "Calificación promedio: " << calificacionPromedio << "\n";
    cout << "Calificación máxima: " << calificacionMaxima << "\n";
    cout << "Calificación mínima: " << calificacionMinima << "\n";
}
    