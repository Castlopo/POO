
#ifndef EVALUACIONCURSO_H
#define EVALUACIONCURSO_H

#include <string>
using namespace std;

class EvaluacionCurso {
public:
    string nombreCurso;
    float calificacionPromedio;
    float calificacionMaxima;
    float calificacionMinima;

    EvaluacionCurso(string nombre = "Curso", float promedio = 0.0, float maxima = 0.0, float minima = 0.0);
    void mostrarDetalles();
};

#endif
    