
#ifndef MATERIA_H
#define MATERIA_H

#include <string>
using namespace std;

class Materia {
private:
    string nombre;
    string codigo;
    int creditos;
    string profesor;

public:
    Materia(string nombre = "", string codigo = "", int creditos = 0, string profesor = "");

    void setNombre(const string& nombre);
    void setCodigo(const string& codigo);
    void setCreditos(int creditos);
    void setProfesor(const string& profesor);

    string getNombre() const;
    string getCodigo() const;
    int getCreditos() const;
    string getProfesor() const;

    void mostrarDetalles() const;
};

void gestionarMaterias();

#endif
    