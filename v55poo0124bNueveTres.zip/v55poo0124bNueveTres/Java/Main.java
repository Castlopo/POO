package v55;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Materia {
    private String clave;
    private String nombre;
    private List<String> prerequisitos;

    // Constructor
    public Materia(String clave, String nombre, List<String> prerequisitos) {
        this.clave = clave;
        this.nombre = nombre;
        this.prerequisitos = prerequisitos;
    }

    // Métodos getter
    public String getClave() {
        return clave;
    }

    public String getNombre() {
        return nombre;
    }

    public List<String> getPrerequisitos() {
        return prerequisitos;
    }
}

public class Main {
    private static List<Materia> materias = new ArrayList<>();

    // Función para inicializar las materias
    public static void inicializarMaterias() {
        List<String> prerequisitos1 = new ArrayList<>();
        prerequisitos1.add("Español");
        prerequisitos1.add("Álgebra");

        List<String> prerequisitos2 = new ArrayList<>();
        prerequisitos2.add("I5247");

        List<String> prerequisitos3 = new ArrayList<>();
        prerequisitos3.add("Aritmética");
        prerequisitos3.add("Trigonometría");
        prerequisitos3.add("I5247");

        List<String> prerequisitos4 = new ArrayList<>();
        prerequisitos4.add("IL352");

        List<String> prerequisitos5 = new ArrayList<>();
        prerequisitos5.add("I5289");
        prerequisitos5.add("IL345");

        List<String> prerequisitos6 = new ArrayList<>();
        prerequisitos6.add("IL354");

        List<String> prerequisitos7 = new ArrayList<>();
        prerequisitos7.add("IL356");

        List<String> prerequisitos8 = new ArrayList<>();
        prerequisitos8.add("IL356");

        List<String> prerequisitos9 = new ArrayList<>();
        prerequisitos9.add("IL354");

        List<String> prerequisitos10 = new ArrayList<>();
        prerequisitos10.add("IL366");
        prerequisitos10.add("CB224");

        materias.add(new Materia("I5247", "Lógica Matemática", prerequisitos1));
        materias.add(new Materia("IL352", "Programación Estructurada", prerequisitos2));
        materias.add(new Materia("IL345", "Matemáticas Discretas", prerequisitos3));
        materias.add(new Materia("I5289", "Programación Orientada a Objetos", prerequisitos4));
        materias.add(new Materia("IL354", "Estructuras de Datos", prerequisitos5));
        materias.add(new Materia("IL356", "Bases de Datos", prerequisitos6));
        materias.add(new Materia("CB224", "Ingeniería de Software", prerequisitos7));
        materias.add(new Materia("IL362", "Programación para Internet", prerequisitos8));
        materias.add(new Materia("IL366", "Sistemas Operativos", prerequisitos9));
        materias.add(new Materia("IL360", "Programación Paralela y Concurrente", prerequisitos10));
    }

    // Función para listar las materias con sus prerequisitos
    public static void listarMaterias() {
        System.out.println("--------------------------------------------------------------------------------");
        System.out.printf("%-10s | %-35s | %s\n", "Clave", "Nombre", "Prerrequisito(s)");
        System.out.println("--------------------------------------------------------------------------------");
        for (Materia materia : materias) {
            System.out.printf("%-10s | %-35s | ", materia.getClave(), materia.getNombre());
            List<String> prerequisitos = materia.getPrerequisitos();
            for (int i = 0; i < prerequisitos.size(); i++) {
                System.out.print(prerequisitos.get(i));
                if (i < prerequisitos.size() - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println();
        }
        System.out.println("--------------------------------------------------------------------------------");
    }

    // Método principal
    public static void main(String[] args) {
        inicializarMaterias(); // Inicializar datos
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\nMenu Principal");
            System.out.println("1. Listar registros");
            System.out.println("2. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    listarMaterias();
                    break;
                case 2:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 2);

        scanner.close();
    }
}
