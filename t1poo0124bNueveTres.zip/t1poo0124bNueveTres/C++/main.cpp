#include <iostream>

using namespace std;

int main() {
    char tablero[3][3];
    char jugadorActual = 'X';
    bool juegoActivo = true;
    int turnos = 0;
    char respuesta = 'S';

    while (respuesta == 'S') {
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                tablero[i][j] = ' ';

        turnos = 0;
        juegoActivo = true;

        while (juegoActivo && turnos < 9) {
            cout << "Juego del Gato v1.0\n";
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 3; ++j) {
                    cout << " " << tablero[i][j];
                    if (j < 2) cout << " |";
                }
                if (i < 2) cout << "\n---------\n";
            }
            cout << "\nEs turno del jugador " << jugadorActual << endl;

            int fila, columna;
            cout << "Dime la fila (1 a 3): ";
            cin >> fila;
            cout << "Dime la columna (1 a 3): ";
            cin >> columna;

            if (fila < 1 || fila > 3 || columna < 1 || columna > 3 || tablero[fila - 1][columna - 1] != ' ') {
                cout << "Movimiento no valido, intenta de nuevo.\n";
                continue;
            }

            tablero[fila - 1][columna - 1] = jugadorActual;
            turnos++;

            for (int i = 0; i < 3; ++i) {
                if ((tablero[i][0] == jugadorActual && tablero[i][1] == jugadorActual && tablero[i][2] == jugadorActual) ||
                    (tablero[0][i] == jugadorActual && tablero[1][i] == jugadorActual && tablero[2][i] == jugadorActual)) {
                    juegoActivo = false;
                }
            }
            if ((tablero[0][0] == jugadorActual && tablero[1][1] == jugadorActual && tablero[2][2] == jugadorActual) ||
                (tablero[0][2] == jugadorActual && tablero[1][1] == jugadorActual && tablero[2][0] == jugadorActual)) {
                juegoActivo = false;
            }

            if (!juegoActivo) {
                cout << "\nEl ganador es el jugador " << jugadorActual << endl;
            } else if (turnos == 9) {
                cout << "\nEmpate, no hay ganador.\n";
                break;
            }

            jugadorActual = (jugadorActual == 'X') ? 'O' : 'X';
        }

        cout << "Otra partida? (S/N): ";
        cin >> respuesta;
        if (respuesta == 'S') {
            jugadorActual = (jugadorActual == 'X') ? 'O' : 'X';
        }
    }

    cout << "Fin del juego.\n";
    return 0;
}
