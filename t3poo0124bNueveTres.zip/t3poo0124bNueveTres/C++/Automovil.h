#ifndef VEHICULO_H
#define VEHICULO_H

#include <string>
using namespace std;

class Vehiculo {
private:
    string marcaVehiculo;
    string modeloVehiculo;
    int anioFabricacion;

public:
    void establecerMarca(const string& marca) { marcaVehiculo = marca; }
    void establecerModelo(const string& modelo) { modeloVehiculo = modelo; }
    void establecerAnio(int anio) { anioFabricacion = anio; }

    string obtenerMarca() const { return marcaVehiculo; }
    string obtenerModelo() const { return modeloVehiculo; }
    int obtenerAnio() const { return anioFabricacion; }

    virtual void mostrarInformacion() const = 0;
};

#endif
