#include <iostream>
#include "Automovil.h"
#include "Motocicleta.h"

int main() {
    Automovil autoToyota;
    autoToyota.establecerMarca("Toyota");
    autoToyota.establecerModelo("Corolla");
    autoToyota.establecerAnio(2021);
    autoToyota.establecerPuertas(4);
    autoToyota.mostrarInformacion();

    Motocicleta motoYamaha;
    motoYamaha.establecerMarca("Yamaha");
    motoYamaha.establecerModelo("MT-07");
    motoYamaha.establecerAnio(2022);
    motoYamaha.establecerCilindrada(689);
    motoYamaha.mostrarInformacion();

    return 0;
}
