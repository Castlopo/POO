#ifndef MOTOCICLETA_H
#define MOTOCICLETA_H

#include "Vehiculo.h"

class Motocicleta : public Vehiculo {
private:
    int cilindradaMotor;

public:
    void establecerCilindrada(int cilindrada) { cilindradaMotor = cilindrada; }
    int obtenerCilindrada() const { return cilindradaMotor; }

    void mostrarInformacion() const override {
        cout << "Motocicleta: " << obtenerMarca() << " " << obtenerModelo()
             << ", Anio: " << obtenerAnio() << ", Cilindrada: " << obtenerCilindrada() << "cc" << endl;
    }
};

#endif

