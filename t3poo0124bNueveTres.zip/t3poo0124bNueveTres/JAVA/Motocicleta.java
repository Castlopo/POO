public class Motocicleta extends Vehiculo {
    private int cilindradaMotor;

    public void establecerCilindrada(int cilindrada) { this.cilindradaMotor = cilindrada; }
    public int obtenerCilindrada() { return this.cilindradaMotor; }

    @Override
    public void mostrarInformacion() {
        System.out.println("Motocicleta: " + obtenerMarca() + ", Modelo: " + obtenerModelo()
                + ", Anio: " + obtenerAnio() + ", Cilindrada: " + obtenerCilindrada() + " cc");
    }
}
