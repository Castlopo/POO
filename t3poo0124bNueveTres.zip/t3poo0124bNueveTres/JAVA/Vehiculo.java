public abstract class Vehiculo {
    private String marcaVehiculo;
    private String modeloVehiculo;
    private int anioFabricacion;

    public void establecerMarca(String marca) { this.marcaVehiculo = marca; }
    public void establecerModelo(String modelo) { this.modeloVehiculo = modelo; }
    public void establecerAnio(int anio) { this.anioFabricacion = anio; }

    public String obtenerMarca() { return this.marcaVehiculo; }
    public String obtenerModelo() { return this.modeloVehiculo; }
    public int obtenerAnio() { return this.anioFabricacion; }

    public abstract void mostrarInformacion();
}
