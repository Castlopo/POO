public class Automovil extends Vehiculo {
    private int numeroPuertas;

    public void establecerPuertas(int puertas) { this.numeroPuertas = puertas; }
    public int obtenerPuertas() { return this.numeroPuertas; }

    @Override
    public void mostrarInformacion() {
        System.out.println("Automovil: " + obtenerMarca() + ", Modelo: " + obtenerModelo()
                + ", Anio: " + obtenerAnio() + ", Puertas: " + obtenerPuertas());
    }
}
