package a8;

public class Main {
    public static void main(String[] args) {
        Automovil autoToyota = new Automovil();
        autoToyota.establecerMarca("Toyota");
        autoToyota.establecerModelo("Corolla");
        autoToyota.establecerAnio(2021);
        autoToyota.establecerPuertas(4);
        autoToyota.mostrarInformacion();

        Motocicleta motoYamaha = new Motocicleta();
        motoYamaha.establecerMarca("Yamaha");
        motoYamaha.establecerModelo("MT-07");
        motoYamaha.establecerAnio(2022);
        motoYamaha.establecerCilindrada(689);
        motoYamaha.mostrarInformacion();
    }
}
