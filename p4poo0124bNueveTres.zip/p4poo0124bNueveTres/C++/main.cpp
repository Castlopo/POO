#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>

#define IVA_PORCENTAJE 0.16
#define NUM_MESES 12

using namespace std;

struct Ingreso {
    string rfc;
    string concepto;
    double monto;
};

struct Gasto {
    string concepto;
    double monto;
    string justificacion;
};

vector<Ingreso> ingresos[NUM_MESES];
vector<Gasto> gastos[NUM_MESES];
int mesSeleccionado = 0;

void mostrarMenu();
void establecerMes();
void capturarIngreso();
void capturarGasto();
void mostrarIngresos();
void mostrarGastos();
void calcularImpuestos();
void eliminarIngreso();
void eliminarGasto();
void buscarIngreso();
void guardarEnArchivo();

int main() {
    int opcionMenu = 0;

    do {
        mostrarMenu();
        cin >> opcionMenu;

        switch (opcionMenu) {
            case 1: establecerMes(); break;
            case 2: capturarIngreso(); break;
            case 3: capturarGasto(); break;
            case 4: mostrarIngresos(); break;
            case 5: mostrarGastos(); break;
            case 6: calcularImpuestos(); break;
            case 7: eliminarIngreso(); break;
            case 8: eliminarGasto(); break;
            case 9: buscarIngreso(); break;
            case 10: guardarEnArchivo(); break;
            case 11:
                cout << "Saliendo del programa.\n";
                break;
            default:
                cout << "Opcion no valida. Intente de nuevo.\n";
                break;
        }

        if (opcionMenu != 11) {
            cout << "\nPresione entrar para continuar . . .";
            cin.ignore();
            cin.get();
            system("cls");
        }

    } while (opcionMenu != 11);

    return 0;
}

void mostrarMenu() {
    cout << "\n--- Menu ---\n";
    cout << "1. Establecer mes para captura (mes actual: " << mesSeleccionado + 1 << ")\n";
    cout << "2. Captura de ingresos\n";
    cout << "3. Captura de gastos\n";
    cout << "4. Mostrar lista de ingresos anual\n";
    cout << "5. Mostrar lista de gastos anual\n";
    cout << "6. Calculo de impuestos anual\n";
    cout << "7. Eliminar un ingreso\n";
    cout << "8. Eliminar un gasto\n";
    cout << "9. Buscar ingresos\n";
    cout << "10. Guardar en archivo\n";
    cout << "11. Salir\n";
    cout << "Seleccione una opcion: ";
}

void establecerMes() {
    cout << "Elige el mes (1-12): ";
    cin >> mesSeleccionado;
    mesSeleccionado--;
    if (mesSeleccionado < 0 || mesSeleccionado >= NUM_MESES) {
        cout << "Mes invalido. Establecido a Enero.\n";
        mesSeleccionado = 0;
    }
    cout << "Mes establecido en " << mesSeleccionado + 1 << endl;
}

void capturarIngreso() {
    Ingreso ingreso;
    cout << "Captura de ingresos para el mes " << mesSeleccionado + 1 << "\n";
    cout << "RFC: ";
    cin >> ingreso.rfc;
    if (ingreso.rfc.length() < 12 || ingreso.rfc.length() > 13) {
        cout << "Error: El RFC debe tener entre 12 y 13 caracteres.\n";
        return;
    }

    cout << "Concepto: ";
    cin.ignore();
    getline(cin, ingreso.concepto);
    if (ingreso.concepto.length() > 40) {
        cout << "Error: El concepto no puede exceder 40 caracteres.\n";
        return;
    }

    cout << "Monto: ";
    cin >> ingreso.monto;
    ingresos[mesSeleccionado].push_back(ingreso);
    cout << "Ingreso capturado exitosamente.\n";
}

void capturarGasto() {
    Gasto gasto;
    cout << "Captura de gastos para el mes " << mesSeleccionado + 1 << "\n";
    cout << "Concepto: ";
    cin.ignore();
    getline(cin, gasto.concepto);
    if (gasto.concepto.length() > 40) {
        cout << "Error: El concepto no puede exceder 40 caracteres.\n";
        return;
    }

    cout << "Monto: ";
    cin >> gasto.monto;
    cout << "Justificacion: ";
    cin.ignore();
    getline(cin, gasto.justificacion);
    gastos[mesSeleccionado].push_back(gasto);
    cout << "Gasto capturado exitosamente.\n";
}

void mostrarIngresos() {
    cout << "\n--- Lista de Ingresos Anual ---\n";
    cout << left << setw(5) << "#" << setw(10) << "Mes" << setw(15) << "RFC" << setw(20) << "Concepto" << setw(10) << "Monto" << endl;
    int count = 1;
    for (int mes = 0; mes < NUM_MESES; mes++) {
        for (const auto& ingreso : ingresos[mes]) {
            cout << left << setw(5) << count++ << setw(10) << mes + 1 << setw(15) << ingreso.rfc << setw(20) << ingreso.concepto << setw(10) << fixed << setprecision(2) << ingreso.monto << endl;
        }
    }
}

void mostrarGastos() {
    cout << "\n--- Lista de Gastos Anual ---\n";
    cout << left << setw(5) << "#" << setw(10) << "Mes" << setw(20) << "Concepto" << setw(15) << "Monto" << setw(25) << "Justificacion" << endl;
    int count = 1;
    for (int mes = 0; mes < NUM_MESES; mes++) {
        for (const auto& gasto : gastos[mes]) {
            cout << left << setw(5) << count++ << setw(10) << mes + 1 << setw(20) << gasto.concepto << setw(15) << fixed << setprecision(2) << gasto.monto << setw(25) << gasto.justificacion << endl;
        }
    }
}

void calcularImpuestos() {
    double totalIngresos = 0, totalGastos = 0;
    for (int mes = 0; mes < NUM_MESES; mes++) {
        for (const auto& ingreso : ingresos[mes]) {
            totalIngresos += ingreso.monto;
        }
        for (const auto& gasto : gastos[mes]) {
            totalGastos += gasto.monto;
        }
    }
    double impuestos = totalIngresos * IVA_PORCENTAJE - totalGastos;
    cout << "Calculo de impuestos anual:\n";
    cout << "Total ingresos: " << totalIngresos << "\n";
    cout << "Total gastos: " << totalGastos << "\n";
    cout << "Impuestos: " << impuestos << "\n";
}

void eliminarIngreso() {
    int numero;
    cout << "Ingrese el numero de ingreso que desea eliminar: ";
    cin >> numero;
    if (numero > 0 && numero <= ingresos[mesSeleccionado].size()) {
        ingresos[mesSeleccionado].erase(ingresos[mesSeleccionado].begin() + numero - 1);
        cout << "Ingreso eliminado.\n";
    } else {
        cout << "Numero de ingreso no valido.\n";
    }
}

void eliminarGasto() {
    int numero;
    cout << "Ingrese el numero de gasto que desea eliminar: ";
    cin >> numero;
    if (numero > 0 && numero <= gastos[mesSeleccionado].size()) {
        gastos[mesSeleccionado].erase(gastos[mesSeleccionado].begin() + numero - 1);
        cout << "Gasto eliminado.\n";
    } else {
        cout << "Numero de gasto no valido.\n";
    }
}

void buscarIngreso() {
    string rfc;
    cout << "Ingrese el RFC a buscar: ";
    cin >> rfc;
    bool encontrado = false;
    for (int mes = 0; mes < NUM_MESES; mes++) {
        for (const auto& ingreso : ingresos[mes]) {
            if (ingreso.rfc.find(rfc) != string::npos) {
                cout << "Ingreso encontrado en mes " << mes + 1 << ": RFC = " << ingreso.rfc << ", Concepto = " << ingreso.concepto << ", Monto = " << ingreso.monto << endl;
                encontrado = true;
            }
        }
    }
    if (!encontrado) {
        cout << "No se encontraron ingresos con el RFC proporcionado.\n";
    }
}

void guardarEnArchivo() {
    cout << "Funcion de guardado en archivo en construccion.\n";
}

