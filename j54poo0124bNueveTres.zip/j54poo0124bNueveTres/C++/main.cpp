#include <stdio.h>
#include <string.h>

// Definici�n de la estructura Alumno
typedef struct {
    int id;
    char nombre[50];
    int edad;
    float promedio;
} Alumno;

// Funci�n para agregar un nuevo registro de Alumno
void agregarRegistro(Alumno *registros, int *cantidad) {
    printf("Ingrese ID: ");
    scanf("%d", &registros[*cantidad].id);
    printf("Ingrese Nombre: ");
    scanf("%s", registros[*cantidad].nombre);
    printf("Ingrese Edad: ");
    scanf("%d", &registros[*cantidad].edad);
    printf("Ingrese Promedio: ");
    scanf("%f", &registros[*cantidad].promedio);
    (*cantidad)++;
    printf("Registro agregado exitosamente.\n");
}

// Funci�n para buscar un Alumno por ID
int buscarRegistro(Alumno *registros, int cantidad, int id) {
    for (int i = 0; i < cantidad; i++) {
        if (registros[i].id == id) {
            return i;  // Retorna el �ndice del registro encontrado
        }
    }
    return -1;  // Retorna -1 si no se encuentra el registro
}

// Funci�n para reemplazar un registro de Alumno
void reemplazarRegistro(Alumno *registros, int cantidad, int id) {
    int indice = buscarRegistro(registros, cantidad, id);
    if (indice != -1) {
        printf("Ingrese nuevo Nombre: ");
        scanf("%s", registros[indice].nombre);
        printf("Ingrese nueva Edad: ");
        scanf("%d", &registros[indice].edad);
        printf("Ingrese nuevo Promedio: ");
        scanf("%f", &registros[indice].promedio);
        printf("Registro reemplazado exitosamente.\n");
    } else {
        printf("Registro no encontrado.\n");
    }
}

// Funci�n principal con men� de opciones
int main() {
    Alumno registros[100];
    int cantidad = 0;  // Cantidad de registros en el arreglo
    int opcion, id;

    do {
        printf("\n--- MENU ---\n");
        printf("1. Agregar Alumno\n");
        printf("2. Buscar Alumno\n");
        printf("3. Reemplazar Alumno\n");
        printf("4. Salir\n");
        printf("Seleccione una opci�n: ");
        scanf("%d", &opcion);

        switch (opcion) {
            case 1:
                agregarRegistro(registros, &cantidad);
                break;
            case 2:
                printf("Ingrese ID para buscar: ");
                scanf("%d", &id);
                int indice = buscarRegistro(registros, cantidad, id);
                if (indice != -1) {
                    printf("Alumno encontrado:\n");
                    printf("ID: %d\n", registros[indice].id);
                    printf("Nombre: %s\n", registros[indice].nombre);
                    printf("Edad: %d\n", registros[indice].edad);
                    printf("Promedio: %.2f\n", registros[indice].promedio);
                } else {
                    printf("Alumno no encontrado.\n");
                }
                break;
            case 3:
                printf("Ingrese ID para reemplazar: ");
                scanf("%d", &id);
                reemplazarRegistro(registros, cantidad, id);
                break;
            case 4:
                printf("Saliendo...\n");
                break;
            default:
                printf("Opci�n inv�lida.\n");
        }
    } while (opcion != 4);

    return 0;
}
