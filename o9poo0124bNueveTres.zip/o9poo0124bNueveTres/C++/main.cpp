/*
NickName: NueveTres
o9
Tiempo: 01:10
*/
#include <iostream>
#include <string>

using namespace std;


const char CONIFERO = 'C';     // Tipo de árbol Conífero
const char FICCION = 'F';      // Categoría Ficción
const string ARBOL_DEFECTO = "Desconocido";  // Nombre por defecto para el árbol
const string LIBRO_DEFECTO = "Desconocido";  // Título por defecto para el libro


class Arbol {
private:
    string nombreArbol;
    char tipoArbol;
    int edadArbol;
    float alturaArbol;

public:
    Arbol() : nombreArbol(ARBOL_DEFECTO), tipoArbol(' '), edadArbol(0), alturaArbol(0.0f) {}
    Arbol(string nombre, char tipo, int edad, float altura)
        : nombreArbol(nombre), tipoArbol(tipo), edadArbol(edad), alturaArbol(altura) {}

    string dameNombreArbol() const { return nombreArbol; }
    char dameTipoArbol() const { return tipoArbol; }
    int dameEdadArbol() const { return edadArbol; }
    float dameAlturaArbol() const { return alturaArbol; }
};

class Libro {
private:
    string tituloLibro;
    char categoriaLibro;
    int paginasLibro;
    float precioLibro;

public:
    Libro() : tituloLibro(LIBRO_DEFECTO), categoriaLibro(' '), paginasLibro(0), precioLibro(0.0f) {}
    Libro(string titulo, char categoria, int paginas, float precio)
        : tituloLibro(titulo), categoriaLibro(categoria), paginasLibro(paginas), precioLibro(precio) {}

    string dameTituloLibro() const { return tituloLibro; }
    char dameCategoriaLibro() const { return categoriaLibro; }
    int damePaginasLibro() const { return paginasLibro; }
    float damePrecioLibro() const { return precioLibro; }
};


void capturarDatosArbol(string& nombre, char& tipo, int& edad, float& altura) {
    cout << "Introduce el nombre del arbol: ";
    cin.ignore();
    getline(cin, nombre);
    cout << "Introduce el tipo del arbol (C para conífero): ";
    cin >> tipo;
    cout << "Introduce la edad del arbol: ";
    cin >> edad;
    cout << "Introduce la altura del arbol (en metros): ";
    cin >> altura;
}


void capturarDatosLibro(string& titulo, char& categoria, int& paginas, float& precio) {
    cout << "Introduce el titulo del libro: ";
    cin.ignore();
    getline(cin, titulo);
    cout << "Introduce la categoria del libro (F para ficción): ";
    cin >> categoria;
    cout << "Introduce el numero de paginas: ";
    cin >> paginas;
    cout << "Introduce el precio del libro: ";
    cin >> precio;
}

void imprimirDatosArbol(const Arbol* arbol) {
    cout << "Datos del árbol:" << endl;
    cout << "Nombre: " << arbol->dameNombreArbol() << endl;
    cout << "Tipo: " << arbol->dameTipoArbol() << endl;
    cout << "Edad: " << arbol->dameEdadArbol() << " anios" << endl;
    cout << "Altura: " << arbol->dameAlturaArbol() << " metros" << endl;
}

// Subrutina para imprimir datos del libro
void imprimirDatosLibro(const Libro* libro) {
    cout << "
Datos del libro:" << endl;
    cout << "Titulo: " << libro->dameTituloLibro() << endl;
    cout << "Categoria: " << libro->dameCategoriaLibro() << endl;
    cout << "Paginas: " << libro->damePaginasLibro() << endl;
    cout << "Precio: $" << libro->damePrecioLibro() << endl;
}

int main() {
    Arbol* arbol = nullptr;
    Libro* libro = nullptr;

    string nombreArbol, tituloLibro;
    char tipoArbol, categoriaLibro;
    int edadArbol, paginasLibro;
    float alturaArbol, precioLibro;

    capturarDatosArbol(nombreArbol, tipoArbol, edadArbol, alturaArbol);

    capturarDatosLibro(tituloLibro, categoriaLibro, paginasLibro, precioLibro);

    arbol = new Arbol(nombreArbol, tipoArbol, edadArbol, alturaArbol);
    libro = new Libro(tituloLibro, categoriaLibro, paginasLibro, precioLibro);

    imprimirDatosArbol(arbol);
    imprimirDatosLibro(libro);

    delete arbol;
    delete libro;

    return 0;
}
