#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h> // Para usar system("cls")

#define MAX_ALUMNOS 100

typedef struct {
    char nombre[50];
    char matricula[15];
    float promedio;
    int anio;
} Alumno;

bool registrosLibres[MAX_ALUMNOS]; // Arreglo de booleanos para representar si un registro esta libre

void inicializarRegistros(Alumno arr[], int tam) {
    for (int i = 0; i < tam; i++) {
        registrosLibres[i] = true; // Marca todos los registros como libres
    }
}

void limpiarConsola() {
    system("cls"); // Comando para limpiar la consola en Windows
}

void agregarAlumno(Alumno arr[], int tam) {
    limpiarConsola();
    for (int i = 0; i < tam; i++) {
        if (registrosLibres[i]) {
            printf("Nombre: ");
            scanf(" %[^\n]", arr[i].nombre);
            printf("Matricula: ");
            scanf("%s", arr[i].matricula);
            printf("Promedio: ");
            scanf("%f", &arr[i].promedio);
            printf("Anio: ");
            scanf("%d", &arr[i].anio);
            registrosLibres[i] = false; // Marca la celda como ocupada
            printf("Alumno agregado correctamente.\n");
            return;
        }
    }
    printf("No hay espacio para mas alumnos.\n");
}

void listarAlumnos(Alumno arr[], int tam) {
    limpiarConsola();
    printf("\nAlumnos registrados:\n");
    for (int i = 0; i < tam; i++) {
        if (!registrosLibres[i]) {
            printf("Nombre: %s, Matricula: %s, Promedio: %.2f, Anio: %d\n",
                   arr[i].nombre, arr[i].matricula, arr[i].promedio, arr[i].anio);
        }
    }
}

void eliminarAlumno(Alumno arr[], int tam) {
    limpiarConsola();
    int indice;
    printf("Ingrese el indice del alumno a eliminar (1 a %d): ", tam);
    scanf("%d", &indice);
    indice -= 1;

    if (indice >= 0 && indice < tam && !registrosLibres[indice]) {
        registrosLibres[indice] = true; // Marca la celda como libre
        printf("Alumno eliminado correctamente.\n");
    } else {
        printf("Indice invalido o alumno no encontrado.\n");
    }
}

int main() {
    Alumno alumnos[MAX_ALUMNOS];
    inicializarRegistros(alumnos, MAX_ALUMNOS);

    int opcion;
    do {
        printf("\nMenu:\n1. Agregar Alumno\n2. Listar Alumnos\n3. Eliminar Alumno\n4. Salir\n");
        printf("Seleccione una opcion: ");
        scanf("%d", &opcion);

        limpiarConsola();
        switch(opcion) {
            case 1: agregarAlumno(alumnos, MAX_ALUMNOS); break;
            case 2: listarAlumnos(alumnos, MAX_ALUMNOS); break;
            case 3: eliminarAlumno(alumnos, MAX_ALUMNOS); break;
            case 4: printf("Saliendo del programa.\n"); break;
            default: printf("Opcion no valida.\n");
        }
    } while (opcion != 4);

    return 0;
}
